<?php ?>

<form action="page1.php" method="post">
    <input type="submit" onclick="page1.php" name="Back" value='<?php echo "BACK TO STORE" ?>'>
</form>
<h1>CHECKOUT</h1>
